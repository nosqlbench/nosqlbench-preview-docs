---
weight: 55983668
title: opensearch NB Adapter
---
# opensearch NB Adapter

Put docs here
