---
weight: 470823
title: Data API
---
# Data API
## DataStax Data API Adapter

