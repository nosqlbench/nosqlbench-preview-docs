---
title: Data API
weight: 470823
---
# Data API
## DataStax Data API Adapter

